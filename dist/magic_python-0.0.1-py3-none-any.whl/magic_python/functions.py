def length(string: string):
	return len(string)
