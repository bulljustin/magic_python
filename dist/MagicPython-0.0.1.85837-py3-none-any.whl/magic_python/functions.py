def length(obj: object):
	return len(obj)

def string(obj: object):
	return str(obj)