from nose.tools import *
from magic_python.numbers import *

def setup():
	print("setup")

def teardown():
	print("teardown")

def test_basic():
	assert(True)
