
class file:
	WRITE = 'w'
	READ_ONLY = 'r'
	APPEND = 'a'

