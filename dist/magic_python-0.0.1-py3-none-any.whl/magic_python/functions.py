def length(string: object):
	return len(string)
